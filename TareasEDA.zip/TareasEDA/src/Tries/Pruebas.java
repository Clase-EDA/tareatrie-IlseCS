package Tries;

import java.util.Scanner;
import java.io.*; 

/** 
 * <pre>
 * Clase Pruebas
 * 
 * Clase que contiene los método snecesarios para calcular los tiempos que se
 * tarda en ordenar palabras.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class Pruebas {
    
    //merge sort
    public static <T extends Comparable<T>> void mergeSort(T[] datos, int min, int max){
        T[] aux;
        int indice, izq, der;
        if(min==max)
            return;
        int size=max-min+1;
        int mitad=(max+min)/2;
        aux=(T[])(new Comparable[size]);
        mergeSort(datos, min, mitad);
        mergeSort(datos, mitad+1, max);
        izq=min;
        der=mitad+1;
       
        for(int i=0; i<size; i++){
            if(izq<=mitad && der<=max){
                if(datos[izq].compareTo(datos[der])<0)
                    aux[i]=datos[izq++]; //aumenta izq después de usarlo
                else{
                    aux[i]=datos[der++];
                }
            }//cierre segundo if
            else{
                if(izq<=mitad){
                    aux[i]=datos[izq++];
                }//cierre tercer iff
                else{
                    aux[i]=datos[der++];
                }
            }//cierre tercer else
            }//fin del for
        for(int i=0; i<size; i++){
            datos[i+min]=aux[i];
        }//cierre del for
    }//fin del método
    
    //MAIN
    public static void main(String[] args) throws FileNotFoundException {
        //para insertar las palabras 
        int num=50000;
        int i=0;

        // se usan estas variables para determinar cuanto tarda cada metodo
        long start, end;
        double tot; 

//----------------------- TIEMPOS MÉTODO LEXICOGRÁFICO -------------------------

//        //characters utilizados en el TrieTree
//        Character [] letras = {'a','b','c','d','e','f','g','h','i','j','k',
//                               'l','m','n','o','p','q','r','s','t','u','v',
//                               'w','x','y','z'};
//        
//        //declaración del árbol
//        TrieTree tree = new TrieTree(letras);
//
//        //para ingresar los datos del archivo de texto al árbol
//        try {
//            FileReader inputFile = new FileReader("palabras.txt");
//            try {
//                Scanner parser = new Scanner(inputFile);
//                while (parser.hasNextLine() && i<=num){
//                    System.out.println(i);
//                    //leer
//                    String line = parser.nextLine();
//                    //System.out.println(line);
//                    //insertar
//                    tree.inserta(line);
//                    //System.out.println("\n" + tree.busca(line));
//                    i++;
//                }//cierre while
//                System.out.println(i);
//            }//cierre primer try
//            finally {
//                inputFile.close();
//            }//cierre finally
//        } catch(FileNotFoundException exception) {
//            System.out.println("palabras.txt" + " not found");
//        } catch(IOException exception){
//	System.out.println("Unexpected I/O error occured.");
//        }//cierre segundo catch
//        
//        //para obtener los tiempos
//        start = System.nanoTime();
//        tree.toString();
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
 //----------------------- TIEMPOS MÉTODO MERGESORT ----------------------------       
        
        //auxiliares
        num=50000;
        i=0;
 
        //arreglo que se utilizará para el mergeSort
        String [] palabras = new String [num];
        
        //para agregar las palabras del archivo de texto al arreglo
        try {
            FileReader inputFile = new FileReader("palabras.txt");
            try {
                Scanner parser = new Scanner(inputFile);
                while (parser.hasNextLine() && i<num){
                    //System.out.println(i);
                    //leer
                    String line = parser.nextLine();
                    //System.out.println(line);
                    //insertar
                    palabras[i]=line;
                    //System.out.println("\n"+palabras[i]);
                    i++;
                }//cierre while
                System.out.println(i);
            }//cierre primer try
            finally {
                inputFile.close();
            }//cierre finally
        } catch(FileNotFoundException exception) {
            System.out.println("palabras.txt" + " not found");
        } catch(IOException exception){
	System.out.println("Unexpected I/O error occured.");
        }//cierre segundo catch
 
        start = System.nanoTime();
        mergeSort(palabras, 0, palabras.length-1);
        end = System.nanoTime();
        tot = ((end - start)/1000000);
        System.out.println("\n Método: mergeSort"
                           + "\n Número de datos: " + num
                           + "\nTiempo: "+tot+"ms");
 
 
    }//end main 
}//end class
