package Tries;

/** 
 * <pre>
 * Clase NodoTrie
 * 
 * Clase que define la estructura NodoTrie que servirá para almacenar y enlazar
 * los datos guardados en un TrieTree.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class TrieNode {
    //auxiliar
    protected static final int MAX=26;
    //arreglo dentro del nodo
    TrieNode[] hijos = new TrieNode[MAX]; 
    //indica si ya se llegó al fin de la palabra
    protected boolean finPalabra; 
    //contar hijos
    int count;
    
    //gets y sets
    public boolean finPalabra() {
        return finPalabra;
    }

    public void setFinPalabra(boolean finPalabra) {
        this.finPalabra = finPalabra;
    }
    
    //constructor
    public TrieNode(){ 
        //crear arreglo
        this.hijos = new TrieNode [MAX];
        //crear el nodo e insertar el dato
        //poner fin palabra en falso (estado base)
        finPalabra = false; 
        //número de hijos (estado base)
        count = 0;
    }//end constructor

}//end class
