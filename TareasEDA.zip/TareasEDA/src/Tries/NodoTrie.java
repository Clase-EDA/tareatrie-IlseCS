package Tries;

/** 
 * <pre>
 * Clase NodoTrie
 * 
 * Clase que define la estructura NodoTrie que servirá para almacenar y enlazar
 * los datos guardados en un TrieTree.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class NodoTrie {
    //auxiliar
    protected static final int MAX=26;
    //arreglo dentro del nodo
    NodoTrie[] hijos = new NodoTrie[MAX]; 
    //indica si ya se llegó al fin de la palabra
    protected boolean isFinPalabra; 
    //para nodo simple
    protected Character element;
    protected boolean isRoot;
    protected int numHijos;
    
    //gets y sets
    public boolean isFinPalabra() {
        return isFinPalabra;
    }
    
    public boolean isRoot() {
        return isRoot;
    }

    public void setFinPalabra(boolean isFinPalabra) {
        this.isFinPalabra = isFinPalabra;
    }
    
    public void setRoot(boolean isRoot) {
        this.isRoot = isRoot;
    }
    
    public Character getElement() {
        return element;
    }

    public void setElement(Character element) {
        this.element = element;
    }

    public int getNumHijos() {
        return numHijos;
    }

    public void setNumHijos(int numHijos) {
        this.numHijos = numHijos;
    }
    
    //constructor
    NodoTrie(Character letra, int index){ 
        //crear arreglo
        NodoTrie [] hijos = new NodoTrie [MAX];
        //crear el nodo e insertar el dato
        NodoTrie nuevo = new NodoTrie(letra);
        //insertar el nodo en el arreglo
        hijos[index]=nuevo;
        //poner fin palabra en falso (estado base)
        isFinPalabra = false; 
        isRoot = false;
        numHijos = 0;
    }//end constructor
    
    //constructor simple
    NodoTrie (Character element){
         this.element=element;
    }
    
    //constructor vacío
    NodoTrie (){
    }
 
}//end NodoTrie

