package Tries;

import java.util.Scanner;
import java.io.*; 
import java.util.ArrayList;

/** 
 * <pre>
 * Clase Pruebas
 * 
 * Clase que contiene los método snecesarios para calcular los tiempos que se
 * tarda en ordenar palabras.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class PruebasTrie {
    
    //para ingresar datos
    public static void lectura (int num, int i, String [] palabras){
        //para ingresar los datos del archivo de texto al árbol
        try {
            FileReader inputFile = new FileReader("palabras.txt");
            try {
                Scanner parser = new Scanner(inputFile);
                while (parser.hasNextLine() && i<num){
                    //leer
                    String line = parser.nextLine();
                    //insertar
                    palabras[i]=line;
                    i++;
                }//cierre while
            }//cierre primer try
            finally {
                inputFile.close();
            }//cierre finally
        } catch(FileNotFoundException exception) {
            System.out.println("palabras.txt" + " not found");
        } catch(IOException exception){
	System.out.println("Unexpected I/O error occured.");
        }//cierre segundo catch
    }//end lectura
    
    //para meter datos al trie
    public static void ordena(Trie tree, String [] palabras){
        //para pasar los datos del arreglo al trie y ordenar
        for (int i=0;i<palabras.length;i++){
            tree.inserta(palabras[i]);
        }//cierre del for
        ArrayList<String> lista = new ArrayList();
        //ordenar
        tree.ordenaLex(lista);
    }//end ordena
    
//------------------------------------ MAIN ------------------------------------
    
    public static void main(String[] args) throws FileNotFoundException {
        // se usan estas variables para determinar cuanto tarda cada metodo
        long start, end;
        double tot; 

//----------------------- TIEMPOS MÉTODO LEXICOGRÁFICO -------------------------

        //characters utilizados en el TrieTree
        Character [] letras = {'a','b','c','d','e','f','g','h','i','j','k',
                               'l','m','n','o','p','q','r','s','t','u','v',
                               'w','x','y','z'};
        
        //aux
        int num=1000;
        
        //declaración del árbol
        Trie tree = new Trie(letras);
        
        //para insertar las palabras 
        String [] palabras = new String [num];
        lectura(num, 0, palabras);
        
        //empezar a medir el tiempo
        start = System.nanoTime();
        ordena(tree, palabras);
        end = System.nanoTime();
        tot = ((end - start)/1000000);
        System.out.println("\n Método: lexicográfico"
                           + "\n Número de datos: " + num
                           + "\nTiempo: "+ tot + "ms");
        
//        num=5000;
//        
//        //declaración del árbol
//        Trie tree2 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras2 = new String [num];
//        lectura(num, 0, palabras2);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree2, palabras2);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=10000;
//        
//        //declaración del árbol
//        Trie tree3 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras3 = new String [num];
//        lectura(num, 0, palabras3);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree3, palabras3);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=15000;
//        
//        //declaración del árbol
//        Trie tree4 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras4 = new String [num];
//        lectura(num, 0, palabras4);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree4, palabras4);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=20000;
//        
//        //declaración del árbol
//        Trie tree5 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras5 = new String [num];
//        lectura(num, 0, palabras5);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree5, palabras5);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=25000;
//        
//        //declaración del árbol
//        Trie tree6 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras6 = new String [num];
//        lectura(num, 0, palabras6);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree6, palabras6);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=30000;
//        
//        //declaración del árbol
//        Trie tree7 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras7 = new String [num];
//        lectura(num, 0, palabras7);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree7, palabras7);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=35000;
//        
//        //declaración del árbol
//        Trie tree8 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras8 = new String [num];
//        lectura(num, 0, palabras8);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree8, palabras8);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=40000;
//        
//        //declaración del árbol
//        Trie tree9 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras9 = new String [num];
//        lectura(num, 0, palabras9);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree9, palabras9);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=45000;
//        
//        //declaración del árbol
//        Trie tree10 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras10 = new String [num];
//        lectura(num, 0, palabras10);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree10, palabras10);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
//        num=50000;
//        
//        //declaración del árbol
//        Trie tree11 = new Trie(letras);
//        
//        //para insertar las palabras 
//        String [] palabras11 = new String [num];
//        lectura(num, 0, palabras11);
//        
//        //empezar a medir el tiempo
//        start = System.nanoTime();
//        ordena(tree11, palabras11);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: lexicográfico"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+ tot + "ms");
        
    }//end main
}//end class
