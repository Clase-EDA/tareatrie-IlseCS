package Tries;

import java.util.ArrayList;

/** 
 * <pre>
 * Clase AVLTree
 * 
 * Clase que contiene los método snecesarios para insertar, borrar, buscar,  
 * imprimir y ordenar los datos (forma alfabética) de un TrieTree.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class Trie {
    protected TrieNode root;
    //arreglo de símbolos 
    protected Character [] simbolos;
    //auxiliar para determinar el length máximo 
    protected static final int MAX=26;
    
    //constructor
    public Trie(Character[] arre){   
        //verificar que el length máximo sea respetado
        if (arre.length==MAX){
            //construir root
            this.root = new TrieNode();
            //ordenar el arreglo recibido
            mergeSort(arre,0,MAX-1);
            this.simbolos = arre.clone();
        } else 
            throw new EmptyCollectionException("\nVerifique length de arreglo de símbolos");
    }//end constructor
    
    //método para determinar si el trie tree está vacío
    public boolean isEmpty(TrieNode nodo) {
        //auxiliares
        int i=0;
        boolean flag=true;
        //para recorrer el arreglo del nodo y determinar si tiene hijos
        while (i<MAX && flag){
            if (nodo.hijos[i]!=null)
                flag=false;
            i++;
        }//cierre del while
        return flag;
    } //end isEmpty
    
    //método auxiliar para ordenar el arreglo de símbolos utilizado
    private <T extends Comparable<T>> void mergeSort(T[] datos, int min, int max){
        T[] aux;
        int indice, izq, der;
        if(min==max)
            return;
        int size=max-min+1;
        int mitad=(max+min)/2;
        aux=(T[])(new Comparable[size]);
        mergeSort(datos, min, mitad);
        mergeSort(datos, mitad+1, max);
        izq=min;
        der=mitad+1;
       
        for(int i=0; i<size; i++){
            if(izq<=mitad && der<=max){
                if(datos[izq].compareTo(datos[der])<0)
                    aux[i]=datos[izq++]; //aumenta izq después de usarlo
                else{
                    aux[i]=datos[der++];
                }
            }//cierre segundo if
            else{
                if(izq<=mitad){
                    aux[i]=datos[izq++];
                }//cierre tercer iff
                else{
                    aux[i]=datos[der++];
                }
            }//cierre tercer else
            }//fin del for
        for(int i=0; i<size; i++){
            datos[i+min]=aux[i];
        }//cierre del for
    }//fin del método
    
//--------------------------- SECCIÓN INSERTAR ---------------------------------
    
    //método público para insertar datos en el árbol
    public void inserta (String palabra){
        //verificar que el elemento sea diferente de nulo
        if (palabra!=null){
            //llamar a método privado
            inserta (palabra, root);
        } else 
            throw new EmptyCollectionException("\nElemento a insertar nulo");
    }//end inserta público
    
    /* método privado para insertar datos en el árbol. Si no se encuentra la
     * letra, se inserta en el Trie. Si se encuentra y es un prefijo, sólo
     * se marca el nodo. */
    private void inserta (String palabra, TrieNode actual){ 
        //auxiliar para determinar en qué posición se inserta el dato 
        int index; 
       //ciclo para recorrer la palabra e insertarla en el trie tree
        for (int i=0; i<palabra.length(); i++) {
            //obtener el lugar del arreglo en el que se inserta
            index=binarySearch(0,MAX-1,palabra.charAt(i));
            //verificar que el símbolo a insertar se encuentre en el arreglo 
            if (index!=-1){
                //en caso de que el dato no haya sido insertado, se crea un nuevo nodo
                if (actual.hijos[index]==null){ 
                   //crear nuevo nodo e insertar
                   actual.hijos[index]=new TrieNode ();
                   //aumentar contador
                   actual.count++;
                   //para seguir recorriendo el trie
                   actual=actual.hijos[index]; 
                } else {
                    //si ya existe el nodo, seguir recorriendo el trie
                    actual=actual.hijos[index];
                }//cierre del else
            } else
                throw new EmptyCollectionException("\nSímbolo no válido");
        } //cierre del for 
        //para marcar el fin de la palabra
        actual.finPalabra=true;
    }//end inserta privado 
    
    /* método auxiliar para determinar la posición del arreglo en la que se 
     * debe de insertar el Character recibido. Regresa un -1 si el elemento 
     * a insertar no se encuentra en el arreglo de símbolos.
     * start = 0
     * end = MAX-1 (length-1)
     * elem = dato a buscar */
    private int binarySearch(int start, int end, int elem) { 
        if (end>=start) { 
            //dividir el arreglo para empezar a trabajar
            int mid=start+(end-start)/2; 
            // Si el elemento se encuentra en el centro
            if (simbolos[mid]==elem) 
                return mid; 
            /* si el elemento es más chico que lo que se encuentra en la mitad
             * se va al lado izquierdo */
            if (simbolos[mid]>elem) 
                return binarySearch(start, mid - 1, elem); 
            //si no se va al lado izquierdo, es más grande y va a la derecha
            return binarySearch(mid + 1, end, elem); 
        }//cierre del primer if 
        //en caso de que no se encuentre el dato
        return -1; 
    }//end binarySearch
    
//---------------------------- SECCIÓN BUSCAR ----------------------------------
    
    //método público para buscar datos en el trie tree
    public boolean busca (String palabra){
        //validación 
        if (palabra!=null && !isEmpty(root))
            return busca (palabra, root);
        else
            throw new EmptyCollectionException("\nElemento nulo");
    }//end search público
    
    //método privado para buscar datos en el trie tree
    public boolean busca (String palabra, TrieNode actual){
        //auxiliar para determinar en qué posición se tiene el dato 
        int index; 
       //ciclo para recorrer la palabra e insertarla en el trie tree
        for (int i=0; i<palabra.length(); i++) {
            //obtener el lugar del arreglo en el que se inserta
            index=binarySearch(0,MAX-1,palabra.charAt(i));
            //verificar que el símbolo a insertar se encuentre en el arreglo 
            if (index!=-1){
                //si el espacio es nulo, no existe el caracter en el trie
                if (actual.hijos[index]==null)
                    return false;
                else {
                    //analizar el siguiente nodo
                    actual=actual.hijos[index];
                } //cierre del else
            } else 
                throw new EmptyCollectionException("\nSímbolo no válido");  
        }//cierre del for
        //al acabar de recorrer verificar si es fin de palabra
        return (actual!=null && actual.finPalabra());
    }//end busca privado
    
//---------------------------- SECCIÓN BORRAR ----------------------------------
    
    //método público para remover Strings del TrieTree
    public boolean borra (String palabra){
        //verificar que el elemento a buscar no sea nulo y que el árbol no esté vacío
        if (palabra!=null && !isEmpty(root)){
            //verificar si la palabra está en el trie
            boolean aux=busca(palabra);
            //si se encuentra, proceder a borrar
            if (aux){
                borra(palabra,root,0,0,palabra.length());
                //verificar si se borró
                aux=busca(palabra);
                //significa que fue borrada
                if (!aux) 
                    return true;
            } else 
                return false;
        } //cierre del if
        return false;
    }//end borra público
    
    //método privado para revomer Strings del TrieTree
    private void borra (String palabra, TrieNode actual, int length, int i, int l){
        //cuando se llega al final de la palabra
        if (length==l-1){
            //moverse al último nodo 
            int index=binarySearch(0,MAX-1,palabra.charAt(0));
            actual=actual.hijos[index];
            //marcar que ya no es final de palabra
            if (actual.finPalabra())
                actual.setFinPalabra(false);
            //disminuir contador
            actual.count--;
            //en caso de no ser prefijo de otra palabra -> se borra nodo
            if (isEmpty(actual)){
                //disminuir contador
                actual.count--;
                actual=null;
            }
        } else {
            //en caso de no ser el último Character
            //obtener el lugar del arreglo en el que se inserta
            int index=binarySearch(0,MAX-1,palabra.charAt(0));
            borra(palabra.substring(1),actual.hijos[index],length+1,i+1,l);
        }//cierre del else
        //caso en que nodo no tiene elementos (porque se borraron) y no es fin
        if (actual!=null && !actual.finPalabra()&& isEmpty(actual)){
            //disminuir contador
            actual.count--;
            actual=null;
        }
    }//end borra privado 
    
//--------------------------- SECCIÓN ORDENAR ----------------------------------
    
    //método público para recorrer el Trie de forma que se obtengan las llaves ordenadas
    public void ordenaLex (ArrayList<String> lista){
            String rep = "";
            ordenaLex(root,lista,rep);
    }//end toString publico
    
    //método privado para recorrer el Trie de forma ordenada
    private void ordenaLex (TrieNode actual, ArrayList<String> palabras, String resp){
        //auxiliar
        int cont=0;
        //para recorrer
        for (int i=0;i<MAX;i++){
            TrieNode aux = actual.hijos[i];
            //agregar String si es final de palabra
            if (aux!=null && aux.finPalabra()){
                resp=resp + simbolos[i];
                palabras.add(resp);
            }//cierre del if
            //seguir recorriendo
            if (aux!=null){
                ordenaLex(aux, palabras, resp + simbolos[i]);
                cont++;
            }//cierre del if
            //verificar si se agregaron todos los hijos de ese nodo
            if (aux!=null){
                if(actual.count == cont)
                    break; 
            }//cierre del if
        }//cierre for
    }//end
    


 
//--------------------------------- MAIN ---------------------------------------
    
    public static void main(String[] args) {
        //characters utilizados en el TrieTree
        Character [] letras = {'a','b','c','d','e','f','g','h','i','j','k',
                               'l','m','n','o','p','q','r','s','t','u','v',
                               'w','x','y','z'};
        
        //declaración del árbol
        Trie tree = new Trie(letras);
        
        //prueba insertar - OK
        tree.inserta("wei");//10
        tree.inserta("wuxian");//12
        tree.inserta("lan");//4
        tree.inserta("wangji");//9
        tree.inserta("ying");//15
        tree.inserta("zhan");//17
        tree.inserta("wen");//11
        tree.inserta("qing");//8
        tree.inserta("ning");//7
        tree.inserta("yuan");//16
        tree.inserta("xie");//13
        tree.inserta("lian");//5
        tree.inserta("hua");//3
        tree.inserta("cheng");//1
        tree.inserta("mu");//6
        tree.inserta("feng");//2
        tree.inserta("xin");//14
        
        //prueba busca - OK
//        System.out.println("\n" + tree.busca("wei"));  //true
//        System.out.println("\n" + tree.busca("wuxian"));  //true
//        System.out.println("\n" + tree.busca("lan"));  //true
//        System.out.println("\n" + tree.busca("wangji"));  //true
//        System.out.println("\n" + tree.busca("ying"));  //true
//        System.out.println("\n" + tree.busca("zhan"));  //true
//        System.out.println("\n" + tree.busca("wen"));  //true
//        System.out.println("\n" + tree.busca("qing"));  //true
//        System.out.println("\n" + tree.busca("ning"));  //true
//        System.out.println("\n" + tree.busca("yuan"));  //true
//        System.out.println("\n" + tree.busca("qiren"));  //false
//        System.out.println("\n" + tree.busca("meng"));   //false

        //prueba borrar - OK
//        System.out.println("\n" + tree.borra("wuxian")); //true
//        System.out.println("\n" + tree.borra("wuxian")); //false (ya se borró)
//        System.out.println("\n" + tree.borra("yao")); //false (no está en trie)

        //prueba ordena - OK
//        ArrayList<String> palabras = new ArrayList();
//        tree.ordenaLex(palabras);
//        System.out.println(palabras.toString());
    }//end main
}//end class
