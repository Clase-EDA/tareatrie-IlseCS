package Tries;

import java.util.Scanner;
import java.io.*; 
import java.util.ArrayList;

/** 
 * <pre>
 * Clase Pruebas
 * 
 * Clase que contiene los método snecesarios para calcular los tiempos que se
 * tarda en ordenar palabras.
 * 
 * </pre>
 * @author Ilse Córdova 181901
 */
public class PruebasMerge {
        //merge sort
    public static <T extends Comparable<T>> void mergeSort(T[] datos, int min, int max){
        T[] aux;
        int indice, izq, der;
        if(min==max)
            return;
        int size=max-min+1;
        int mitad=(max+min)/2;
        aux=(T[])(new Comparable[size]);
        mergeSort(datos, min, mitad);
        mergeSort(datos, mitad+1, max);
        izq=min;
        der=mitad+1;
       
        for(int i=0; i<size; i++){
            if(izq<=mitad && der<=max){
                if(datos[izq].compareTo(datos[der])<0)
                    aux[i]=datos[izq++]; //aumenta izq después de usarlo
                else{
                    aux[i]=datos[der++];
                }
            }//cierre segundo if
            else{
                if(izq<=mitad){
                    aux[i]=datos[izq++];
                }//cierre tercer iff
                else{
                    aux[i]=datos[der++];
                }
            }//cierre tercer else
            }//fin del for
        for(int i=0; i<size; i++){
            datos[i+min]=aux[i];
        }//cierre del for
    }//fin del método
    
        //para ingresar datos
    public static void lectura (int num, int i, String [] palabras){
        //para ingresar los datos del archivo de texto al árbol
        try {
            FileReader inputFile = new FileReader("palabras.txt");
            try {
                Scanner parser = new Scanner(inputFile);
                while (parser.hasNextLine() && i<num){
                    //leer
                    String line = parser.nextLine();
                    //insertar
                    palabras[i]=line;
                    i++;
                }//cierre while
            }//cierre primer try
            finally {
                inputFile.close();
            }//cierre finally
        } catch(FileNotFoundException exception) {
            System.out.println("palabras.txt" + " not found");
        } catch(IOException exception){
	System.out.println("Unexpected I/O error occured.");
        }//cierre segundo catch
    }//end lectura
    
    
    
    public static void main(String[] args) {
        // se usan estas variables para determinar cuanto tarda cada metodo
        long start, end;
        double tot; 

//---------------------------- TIEMPOS MERGESORT -------------------------------
        
        //aux
        int num=1000;
//
//        //para insertar las palabras 
//        String [] palabras = new String [num];
//        lectura(num, 0, palabras);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras, 0, palabras.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=5000;
//        
//        String [] palabras1 = new String [num];
//        lectura(num, 0, palabras1);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras1, 0, palabras1.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=10000;
//        
//        String [] palabras2 = new String [num];
//        lectura(num, 0, palabras2);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras2, 0, palabras2.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=15000;
//        
//        String [] palabras3 = new String [num];
//        lectura(num, 0, palabras3);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras3, 0, palabras3.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=20000;
//        
//        String [] palabras4 = new String [num];
//        lectura(num, 0, palabras4);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras4, 0, palabras4.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=25000;
//        
//        String [] palabras5 = new String [num];
//        lectura(num, 0, palabras5);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras5, 0, palabras5.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=30000;
//        
//        String [] palabras6 = new String [num];
//        lectura(num, 0, palabras6);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras6, 0, palabras6.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=35000;
//        
//        String [] palabras7 = new String [num];
//        lectura(num, 0, palabras7);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras7, 0, palabras7.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=40000;
//        
//        String [] palabras8 = new String [num];
//        lectura(num, 0, palabras8);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras8, 0, palabras8.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
        
//        num=45000;
//        
//        String [] palabras9 = new String [num];
//        lectura(num, 0, palabras9);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras9, 0, palabras9.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
//        num=50000;
//        
//        String [] palabras10 = new String [num];
//        lectura(num, 0, palabras10);
//        
//        //para empezar a medir el tiempo
//        start = System.nanoTime();
//        mergeSort(palabras10, 0, palabras10.length-1);
//        end = System.nanoTime();
//        tot = ((end - start)/1000000);
//        System.out.println("\n Método: mergeSort"
//                           + "\n Número de datos: " + num
//                           + "\nTiempo: "+tot+"ms");
        
    }//end main
}//end class
